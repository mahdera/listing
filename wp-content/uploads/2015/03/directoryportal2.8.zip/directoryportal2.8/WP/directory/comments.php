<?php

// we no need this file in this theme, comment template is in Templates/comments.php