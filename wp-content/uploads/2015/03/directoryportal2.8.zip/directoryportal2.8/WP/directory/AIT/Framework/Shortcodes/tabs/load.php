<?php

require_once "ait-tabs.php";
require_once "ait-accordion.php";
