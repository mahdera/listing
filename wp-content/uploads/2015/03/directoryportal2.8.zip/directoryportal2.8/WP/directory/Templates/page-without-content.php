{extends $layout}

{block content}

{/block}