<form method="get" id="searchform" action="{$homeUrl}">
	<label for="s" class="assistive-text">{_x 'Search', 'assistive-text'}</label>
	<input type="text" class="field" name="s" id="s" placeholder="{_x 'Search', 'search field placeholder'}">
	<input type="submit" class="submit" name="submit" id="searchsubmit" value="{_x 'Search', 'search button text'}">
</form>
