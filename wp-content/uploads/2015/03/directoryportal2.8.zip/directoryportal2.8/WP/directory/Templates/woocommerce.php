{extends $layout}

{block content}

	{? woocommerce_content() }

{/block}